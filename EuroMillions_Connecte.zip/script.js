
async function fetchDraws(limit = 500) {
  const res = await fetch('https://euromillions.api.pedromealha.dev/v1/draws?limit=' + limit);
  const data = await res.json();
  return data;
}

function computeFrequencies(draws) {
  const numFreq = Array(51).fill(0);
  const starFreq = Array(13).fill(0);
  draws.forEach(d => {
    d.numbers.forEach(n => numFreq[n]++);
    d.stars.forEach(s => starFreq[s]++);
  });
  return { numFreq, starFreq };
}

function weightedSample(freqArray, count) {
  const weighted = freqArray.map((v, i) => Array(v).fill(i)).flat();
  const set = new Set();
  while (set.size < count && weighted.length) {
    const rnd = weighted[Math.floor(Math.random() * weighted.length)];
    if (rnd > 0) set.add(rnd);
  }
  return Array.from(set).sort((a, b) => a - b);
}

function generateGrid(numFreq, starFreq) {
  const numbers = weightedSample(numFreq, 5);
  const stars = weightedSample(starFreq, 2);
  return { numbers, stars };
}

async function generateGrids() {
  const count = parseInt(document.getElementById('grids').value);
  const draws = await fetchDraws();
  const { numFreq, starFreq } = computeFrequencies(draws);

  const resultsDiv = document.getElementById('results');
  resultsDiv.innerHTML = '';

  for (let i = 0; i < count; i++) {
    const grid = generateGrid(numFreq, starFreq);
    const p = document.createElement('p');
    p.textContent = `Grille ${i + 1} : ${grid.numbers.join(', ')} ⭐ ${grid.stars.join(', ')}`;
    resultsDiv.appendChild(p);
  }
}
